sudo cp AgeOfSystems -R /usr/share/plymouth/themes/ && sudo plymouth-set-default-theme AgeOfSystems && sudo /usr/lib/plymouth/plymouth-update-initrd && sudo mkinitrd
